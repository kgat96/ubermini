# README

This is the smallest-possible example program using libopencm3.

It's intended for the Jellybean development board from the
[HackRF project](https://github.com/mossmann/hackrf)

It should blink LED1 on the board.
This example copy the Code from ROM to RAM and execute code from RAM.
