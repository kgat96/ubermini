# README

This is the smallest-possible example program using libopencm3.

It's intended for the NXP LPC1343-based
[Olimex LPC-1343 eval board](http://olimex.com/dev/lpc-p1343.html for details).
It should blink a LED on the board.
