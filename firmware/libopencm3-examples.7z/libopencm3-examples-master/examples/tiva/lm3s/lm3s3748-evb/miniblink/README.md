# README

This is the smallest-possible example program using libopencm3.

It's intended for the LuminaryMicro LM3S3748-EVB.
It should blink the STATUS LED on the board.
