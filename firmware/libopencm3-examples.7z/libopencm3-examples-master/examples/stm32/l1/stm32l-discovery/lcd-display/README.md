# README

This example program display word *HELLO* on default LCD screen of
STM32L-DISCOVERY board.

