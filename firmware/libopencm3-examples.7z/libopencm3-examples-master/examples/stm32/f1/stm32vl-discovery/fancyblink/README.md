# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32VLDISCOVERY eval board. It should blink
the LEDs on the board.

