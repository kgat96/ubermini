# README

This is a small RTC example project.

It blinks the ST STM32VLDISCOVERY's blue LED at 1Hz, and sends the value of
the RTC counter register down the serial line (PA9) at 38400,8N1.

