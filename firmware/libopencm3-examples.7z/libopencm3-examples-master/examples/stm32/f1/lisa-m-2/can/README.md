# README

This test sets up the CAN interface on Lisa/M and transmits 8 bites every
100ms. The first byte is being incremented in each cycle. The demo also
receives messages and is displaing the first 4 bits of the first byte on the
board LEDs.
