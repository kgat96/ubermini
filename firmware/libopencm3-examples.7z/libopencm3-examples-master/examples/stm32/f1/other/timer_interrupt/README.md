# README

This example program blinks a LED on PortB Pin 6. 1 second on / 1 second off.
Blinking is made only with the timer interrupt of the TIM2 timer.

