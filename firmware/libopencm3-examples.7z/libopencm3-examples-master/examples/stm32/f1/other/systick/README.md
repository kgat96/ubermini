# README

This example program blinks a LED on PortB Pin 6. 1 second on / 1 second off.
Blinking is done via the systick timer interrupt.

