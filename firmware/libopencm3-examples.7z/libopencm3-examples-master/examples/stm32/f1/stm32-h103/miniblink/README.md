# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32-based
[Olimex STM32-H103 eval board](http://olimex.com/dev/stm32-h103.html).
It should blink the LED on the board.

