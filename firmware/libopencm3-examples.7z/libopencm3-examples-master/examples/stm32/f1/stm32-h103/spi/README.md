# README

This example program repeatedly sends characters on SPI1 on the ST STM32-based
[Olimex STM32-H103 eval board](http://olimex.com/dev/stm32-h103.html).

