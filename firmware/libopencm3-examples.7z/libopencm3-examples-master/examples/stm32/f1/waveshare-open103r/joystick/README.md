# README

This example uses the joystick to control the four LEDs on the
WaveShare Open103R eval board. Joystick directions referenced here are
relative to the text printed on the eval board.  Pressing up will
cycle the LED to a lower numbered LED (e.g. LED4 -> LED3 and LED1 ->
LED4), pressing down will cycle the LED the other way, pressing left
will turn on all LEDs, pressing right will turn off all LEDs, and
pressing center will toggle between blinking and solid on.
