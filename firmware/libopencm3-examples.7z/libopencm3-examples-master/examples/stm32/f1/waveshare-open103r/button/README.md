# README

This example blinks LED1 on the WaveShare Open103R eval board.

When you press the 'USER' button, the blinking is slower.

