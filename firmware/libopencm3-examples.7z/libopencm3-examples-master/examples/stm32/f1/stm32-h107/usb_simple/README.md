# README

This is small USB controlled LED blinking example program using libopencm3.

It's intended for the ST STM32-based
[Olimex STM32-H107 eval board](http://olimex.com/dev/stm32-h107.html).
The usbtest.py script in this directory maybe used to control the LED.

