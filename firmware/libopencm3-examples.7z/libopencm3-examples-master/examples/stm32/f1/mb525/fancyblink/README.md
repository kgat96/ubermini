# README

This is a blink example program using libopencm3.

It's intended for the ST STM32-based
[MB525 eval board](http://www.st.com/stonline/products/literature/um/13472.htm for details).
It should blink the LEDs on the board.

