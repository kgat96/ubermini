# README

I2C example reading from the stm32f3discovery accelerometer.


