# README

This is the smallest-possible example program using libopencm3 and ST
STM32F0DISCOVERY eval board.

It should blink the blue LED on the board.

## Board connections

*none required*
