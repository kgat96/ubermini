# README

This example blinks the green LED on the ST STM32F0DISCOVERY eval board.

When you press the 'USER' button, the blinking is slower.

## Board connections:

*none required*
