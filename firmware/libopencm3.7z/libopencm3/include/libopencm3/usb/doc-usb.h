/** @mainpage libopencm3 Generic USB

@version 1.0.0

@date 10 March 2013

API documentation for Generic USB.

LGPL License Terms @ref lgpl_license
*/

/** @defgroup USB Generic USB
Libraries for Generic USB.

@version 1.0.0

@date 10 March 2013

LGPL License Terms @ref lgpl_license
*/

/** @defgroup USB_defines Generic USB Defines

@brief Defined Constants and Types for Generic USB.

@version 1.0.0

@date 10 March 2013

LGPL License Terms @ref lgpl_license
*/

